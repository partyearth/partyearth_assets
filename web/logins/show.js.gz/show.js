$(document).ready(function(){$("#name").focus();pe.init_page_framework()});
