pe.MissingVenueModule=function(a){a.click(pe.MissingVenueModule.clicked)};pe.MissingVenueModule.clicked=function(){new pe.BottombarMissingVenuePopup($(".BottomBar .MissingVenue"))};
