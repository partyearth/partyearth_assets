$(document).ready(function(){$("#country_name").focus();pe.init_page_framework()});
