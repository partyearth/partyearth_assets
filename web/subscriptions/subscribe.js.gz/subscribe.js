$(document).ready(function(){pe.validate_on_blur($("#email_address"),pe.validation.validate_email_format);pe.init_page_framework()});
