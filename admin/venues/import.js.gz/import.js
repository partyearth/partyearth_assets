$(document).ready(function(){$("#word_text").focus();pe.init_page_framework()});
