CKEDITOR.plugins.setLang("devtools","et",{devTools:{title:"Elemendi andmed",dialogName:"Dialoogiakna nimi",tabName:"Saki nimi",elementId:"Elemendi ID",elementType:"Elemendi liik"}});
