(function(){$(document).ready(function(){if(0<window.parent.length)return window.parent.pe.fire_global_event(pe.events.LOGGED_IN)})}).call(this);
