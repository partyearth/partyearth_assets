$(document).ready(function(){pe.init_page_framework()});
