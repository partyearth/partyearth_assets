(function(){$(document).ready(function(){if(window.parent)return window.parent.pe.fire_global_event(pe.events.LOGGED_IN)})}).call(this);
