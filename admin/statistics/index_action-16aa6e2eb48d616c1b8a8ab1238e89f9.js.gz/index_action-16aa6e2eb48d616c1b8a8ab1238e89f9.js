$(document).ready(function(){$("#start_date").datepicker({showButtonPanel:!0});$("#end_date").datepicker({showButtonPanel:!0});pe.init_page_framework()});
