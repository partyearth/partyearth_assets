CKEDITOR.plugins.setLang("devtools","de",{devTools:{title:"Elementinformation",dialogName:"Dialogfenstername",tabName:"Reitername",elementId:"Element ID",elementType:"Elementtyp"}});
