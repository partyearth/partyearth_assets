CKEDITOR.plugins.setLang("devtools","en",{devTools:{title:"Element Information",dialogName:"Dialog window name",tabName:"Tab name",elementId:"Element ID",elementType:"Element type"}});
