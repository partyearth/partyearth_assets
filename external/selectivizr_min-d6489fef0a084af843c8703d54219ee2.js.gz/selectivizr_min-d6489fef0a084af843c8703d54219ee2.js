(function(){})(this);
