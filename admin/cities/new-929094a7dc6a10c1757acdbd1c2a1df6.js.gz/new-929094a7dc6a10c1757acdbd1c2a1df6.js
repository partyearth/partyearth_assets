$(document).ready(function(){$("#city_name").focus();pe.init_page_framework()});
