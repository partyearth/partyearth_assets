$(document).ready(function(){pe.fire_global_event(pe.events.REGISTRATION_COMPLETE);pe.init_page_framework()});
