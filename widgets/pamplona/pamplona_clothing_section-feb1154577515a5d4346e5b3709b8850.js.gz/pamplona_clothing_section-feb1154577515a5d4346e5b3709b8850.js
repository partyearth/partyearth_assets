pe.PamplonaClothingSection=function(a){pe.init_widget(this,a)};
