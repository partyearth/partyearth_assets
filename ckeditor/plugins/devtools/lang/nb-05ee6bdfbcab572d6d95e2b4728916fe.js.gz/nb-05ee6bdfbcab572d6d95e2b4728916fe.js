CKEDITOR.plugins.setLang("devtools","nb",{devTools:{title:"Elementinformasjon",dialogName:"Navn p\u00e5 dialogvindu",tabName:"Navn p\u00e5 fane",elementId:"Element-ID",elementType:"Elementtype"}});
