CKEDITOR.plugins.setLang("uicolor","nl",{uicolor:{title:"UI Kleurenkiezer",preview:"Live voorbeeld",config:"Plak deze tekst in jouw config.js bestand",predefined:"Voorgedefinieerde kleurensets"}});
