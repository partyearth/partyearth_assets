CKEDITOR.plugins.setLang("devtools","cs",{devTools:{title:"Informace o prvku",dialogName:"N\u00e1zev dialogov\u00e9ho okna",tabName:"N\u00e1zev karty",elementId:"ID prvku",elementType:"Typ prvku"}});
